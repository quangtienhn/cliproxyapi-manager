import fs from 'node:fs';
import path from 'node:path';

// Mask email addresses (e.g., coocaa.s3g@gmail.com -> coo***@gmail.com)
export function maskEmail(email) {
  if (!email || typeof email !== 'string') return '';
  const parts = email.split('@');
  if (parts.length !== 2) return email.slice(0, 3) + '***';
  const name = parts[0];
  const domain = parts[1];
  if (name.length <= 3) {
    return name[0] + '***@' + domain;
  }
  return name.slice(0, 3) + '***@' + domain;
}

// Safely validate filename to prevent directory traversal
export function validateAuthFilename(filename) {
  if (!filename || typeof filename !== 'string') return false;
  // Strictly allow standard auth filename format: <provider>-<identifier>.json
  // No slashes, no backslashes, no .., ends with .json
  const safeRegex = /^[a-zA-Z0-9_\-\.]+$/;
  if (!safeRegex.test(filename)) return false;
  if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) return false;
  return filename.endsWith('.json');
}

export class LocalAuthStore {
  constructor(authDir) {
    this.authDir = authDir;
  }

  // List all accounts from authDir
  listAccounts() {
    if (!fs.existsSync(this.authDir)) {
      return [];
    }

    const files = fs.readdirSync(this.authDir);
    const accounts = [];

    for (const file of files) {
      if (!file.endsWith('.json') || file.startsWith('.')) continue;
      const fullPath = path.join(this.authDir, file);

      try {
        const stat = fs.statSync(fullPath);
        if (!stat.isFile()) continue;

        const content = fs.readFileSync(fullPath, 'utf8');
        const data = JSON.parse(content);

        // Extract metadata safely, without leaking access_token or refresh_token
        const provider = (data.type || data.provider || this.guessProviderFromFilename(file)).toLowerCase();
        const rawEmail = data.email || (data.storage && data.storage.email) || '';
        const rawAccount = data.account || (data.storage && data.storage.account) || data.sub || (data.storage && data.storage.sub) || '';
        const planType = data.plan_type || (data.storage && data.storage.plan_type) || '';

        // Status calculation
        let isExpired = false;
        let expiresAt = null;
        if (data.expired) {
          expiresAt = new Date(data.expired).toISOString();
          isExpired = new Date(data.expired).getTime() < Date.now();
        } else if (data.expires_in && data.last_refresh) {
          const expTime = new Date(data.last_refresh).getTime() + (data.expires_in * 1000);
          expiresAt = new Date(expTime).toISOString();
          isExpired = expTime < Date.now();
        }

        accounts.push({
          filename: file,
          provider,
          emailMasked: rawEmail ? maskEmail(rawEmail) : (rawAccount ? maskEmail(rawAccount) : 'unknown'),
          planType: planType || 'standard',
          status: isExpired ? 'expired' : 'active',
          expiresAt,
          lastRefresh: data.last_refresh || stat.mtime.toISOString(),
          createdAt: stat.birthtime ? stat.birthtime.toISOString() : stat.mtime.toISOString(),
          sizeBytes: stat.size,
          // Explicitly confirm NO tokens are exposed
          hasRefreshToken: Boolean(data.refresh_token || (data.storage && data.storage.refresh_token))
        });
      } catch (err) {
        // Corrupted or invalid JSON file
        accounts.push({
          filename: file,
          provider: this.guessProviderFromFilename(file),
          emailMasked: 'error_reading',
          status: 'corrupted',
          error: err.message,
          sizeBytes: 0,
          hasRefreshToken: false
        });
      }
    }

    return accounts;
  }

  guessProviderFromFilename(filename) {
    const lower = filename.toLowerCase();
    if (lower.startsWith('codex')) return 'codex';
    if (lower.startsWith('xai')) return 'xai';
    if (lower.startsWith('antigravity')) return 'antigravity';
    if (lower.startsWith('claude')) return 'claude';
    return 'unknown';
  }

  // Get specific account safe metadata
  getAccount(filename) {
    if (!validateAuthFilename(filename)) {
      throw new Error('Invalid filename');
    }
    const accounts = this.listAccounts();
    return accounts.find(a => a.filename === filename) || null;
  }

  // Safely delete a specific account
  deleteAccount(filename) {
    if (!validateAuthFilename(filename)) {
      throw new Error('Invalid filename format or potential directory traversal');
    }

    // Explicitly restrict deletion only to recognized provider auth files
    const lower = filename.toLowerCase();
    const isAllowedAuthFile = lower.startsWith('codex-') || lower.startsWith('xai-') || lower.startsWith('antigravity-') || lower.startsWith('claude-');
    if (!isAllowedAuthFile) {
      throw new Error(`File ${filename} is not a recognized provider credential format`);
    }

    const fullPath = path.join(this.authDir, filename);
    if (!fs.existsSync(fullPath)) {
      throw new Error('Account file not found');
    }

    // Atomic / safe unlink
    fs.unlinkSync(fullPath);
    return true;
  }

  // Backup authDir before any modification
  createBackup(backupDir) {
    if (!fs.existsSync(this.authDir)) return null;
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const targetDir = path.join(backupDir || path.dirname(this.authDir), `auths.bak.${timestamp}`);

    fs.mkdirSync(targetDir, { recursive: true });
    const files = fs.readdirSync(this.authDir);
    let count = 0;

    for (const file of files) {
      if (file.endsWith('.json')) {
        const src = path.join(this.authDir, file);
        const dst = path.join(targetDir, file);
        fs.copyFileSync(src, dst);
        count++;
      }
    }

    return { targetDir, count };
  }
}
