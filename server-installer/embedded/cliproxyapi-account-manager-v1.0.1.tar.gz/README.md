# CLIProxyAPI Account Manager

Production-grade, lightweight LAN web application for managing AI provider accounts on **CLIProxyAPI v8.0.61** (TX3 Debian 12 ARM64).

---

## 1. Features
- **LAN Web Dashboard:** View configured AI provider accounts, masked identity, status, expiration, and model catalog without SSH.
- **Provider OAuth Workflows:**
  - **OpenAI Codex:** Browser redirect authentication.
  - **xAI (Grok):** RFC 8628 OAuth2 Device Code Flow (displays user activation code and polls status).
  - **Google Gemini:** Intentionally deferred per safety specifications.
- **Safe Account Management:** Account deletion requires explicit operator confirmation, enforces strict path validation, and triggers an automated credential backup prior to file deletion.
- **Enterprise-Grade Security:**
  - Password hashing with `scrypt` and unique salts.
  - In-memory session tracking with strict TTL and cryptographic CSRF tokens.
  - IP-based rate limiting on login attempts to thwart brute-force attacks.
  - Strict zero-token exposure: tokens, refresh tokens, and internal keys are never transmitted to the browser or logged in audit records.
  - Runs natively under the unprivileged `cliproxyapi` service account.

---

## 2. Quick Start (Local Development)

```bash
# Run tests
npm test

# Start local server
npm start
```

Visit `http://localhost:8320` in your browser.

---

## 3. Deployment Package Overview

The `deploy/` directory provides complete automation for Debian 12 ARM64:
- `deploy.sh`: Preflight validation, systemd unit installation, and service startup.
- `rollback.sh`: Clean rollback preserving audit logs and existing credentials.
- `cliproxyapi-account-manager.service`: Hardened systemd service definition.
- `manager.env.template`: Production configuration template.

---

## 4. Documentation

Comprehensive documentation is organized under `docs/`:
- `ARCHITECTURE.md`: Technical architecture and communication flow.
- `SECURITY-DESIGN.md`: Threat model, credential boundaries, and protection mechanisms.
- `OAUTH-FLOWS.md`: Detailed OAuth workflows for Codex and xAI.
- `PROVIDER-SUPPORT.md`: Matrix of supported, tested, and deferred providers.
- `INSTALLATION.md`: Step-by-step setup guide for TX3.
- `CONFIGURATION.md`: Parameter definitions and environment tuning.
- `OPERATIONS.md`: Routine maintenance and administration runbook.
- `BACKUP-AND-RESTORE.md`: Credential backup, snapshot, and recovery procedures.
- `ROLLBACK.md`: Procedure to restore TX3 to prior state.
- `TEST-REPORT.md`: Automated test execution report.
- `DEPLOYMENT-READINESS.md`: Pre-deployment checklists and verification gates.
- `FINAL-ACCEPTANCE-REPORT.md`: Comprehensive engineering acceptance deliverable.
