#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
BACKUPS="$TMP_DIR/backups"
SOURCE="$TMP_DIR/source"
TARGET="$TMP_DIR/target"
mkdir -p "$BACKUPS" "$SOURCE" "$TARGET/config" "$TARGET/env"
printf 'port: 8317\nmanagement:\n  allow-remote: false\n' > "$SOURCE/config.yaml"
printf 'PORT=8320\nCLIPROXYAPI_URL=http://127.0.0.1:8317\n' > "$SOURCE/manager.env"
printf '#!/usr/bin/env bash\necho "$*" >> "%s"\ncase "$1 $2" in *"is-active"*) echo active;; esac\n' "$TMP_DIR/systemctl.log" > "$TMP_DIR/systemctl"
chmod +x "$TMP_DIR/systemctl"

run_backup() {
  PHASE3_TEST_MODE=1 PHASE3_SOURCE_CONFIG="$SOURCE/config.yaml" PHASE3_SOURCE_ENV="$SOURCE/manager.env" \
  PHASE3_BACKUP_PARENT="$BACKUPS" PHASE3_POINTER_FILE="$BACKUPS/latest_phase3_backup" \
  bash "$ROOT_DIR/deploy/backup_phase3.sh" >/dev/null
  chmod 600 "$BACKUPS/latest_phase3_backup"
}
run_rollback() {
  PHASE3_TEST_MODE=1 PHASE3_BACKUP_PARENT="$BACKUPS" PHASE3_POINTER_FILE="$BACKUPS/latest_phase3_backup" \
  PHASE3_TARGET_CONFIG="$TARGET/config/config.yaml" PHASE3_TARGET_ENV="$TARGET/env/manager.env" \
  PHASE3_SYSTEMCTL_BIN="$TMP_DIR/systemctl" PHASE3_NODE_BIN="node" \
  bash "$ROOT_DIR/deploy/rollback_phase3.sh" >/dev/null
}

echo '[1] actual backup and rollback'
run_backup
run_rollback
test -f "$TARGET/config/config.yaml" && test -f "$TARGET/env/manager.env"

echo '[2] invalid pointer and nested path rejection'
printf '\nextra\n' > "$BACKUPS/latest_phase3_backup"
if run_rollback 2>/dev/null; then exit 1; fi
chmod 600 "$BACKUPS/latest_phase3_backup"
printf '%s/nested/cliproxyapi-phase3-20261110T000000\n' "$BACKUPS" > "$BACKUPS/latest_phase3_backup"
if run_rollback 2>/dev/null; then exit 1; fi

echo '[3] malformed YAML containing port must not restart'
printf 'port: 8317\nmanagement: [broken\n' > "$SOURCE/config.yaml"
run_backup
BACKUP_DIR="$(cat "$BACKUPS/latest_phase3_backup")"
printf 'port: 8317\nmanagement: [broken\n' > "$BACKUP_DIR/config.yaml"
stat -c 'UID=%u GID=%g MODE=%a SIZE=%s' "$BACKUP_DIR/config.yaml" > "$BACKUP_DIR/config.yaml.meta"
(cd "$BACKUP_DIR" && sha256sum config.yaml manager.env config.yaml.meta manager.env.meta > SHA256SUMS)
: > "$TMP_DIR/systemctl.log"
if run_rollback 2>/dev/null; then exit 1; fi
test ! -s "$TMP_DIR/systemctl.log"

echo '[4] failed checksum'
run_backup
BACKUP_DIR="$(cat "$BACKUPS/latest_phase3_backup")"
printf 'tampered\n' >> "$BACKUP_DIR/manager.env"
if run_rollback 2>/dev/null; then exit 1; fi

echo 'All actual backup/rollback integration tests passed.'
