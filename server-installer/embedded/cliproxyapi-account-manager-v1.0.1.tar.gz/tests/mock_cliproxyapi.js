import http from 'node:http';

export function createMockCLIProxyAPI(port = 8399) {
  const accounts = [
    {
      id: 'codex-mock-user@example.com-hash.json',
      provider: 'codex',
      label: 'OpenAI Mock Account',
      email: 'mock-user@example.com',
      storage: {
        access_token: 'synthetic_mock_access_token_12345',
        refresh_token: 'synthetic_mock_refresh_token_67890',
        plan_type: 'free'
      }
    },
    {
      id: 'xai-mock-grok@example.com-hash.json',
      provider: 'xai',
      label: 'xAI Grok Mock',
      email: 'mock-grok@example.com',
      storage: {
        access_token: 'synthetic_mock_grok_token_99999',
        refresh_token: 'synthetic_mock_grok_refresh_88888'
      }
    }
  ];

  const models = [
    { id: 'gpt-4o-mini', object: 'model' },
    { id: 'gpt-4o', object: 'model' },
    { id: 'o1-preview', object: 'model' },
    { id: 'grok-2', object: 'model' },
    { id: 'grok-2-mini', object: 'model' }
  ];

  let pendingOAuthSession = null;

  const server = http.createServer(async (req, res) => {
    const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = parsedUrl.pathname;
    const method = req.method;

    function sendJson(code, data) {
      res.writeHead(code, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data));
    }

    // 1. /v1/models
    if (method === 'GET' && pathname === '/v1/models') {
      return sendJson(200, { data: models });
    }

    // 2. /v1/chat/completions
    if (method === 'POST' && pathname === '/v1/chat/completions') {
      return sendJson(200, {
        id: 'chatcmpl-mock-123',
        model: 'gpt-4o-mini',
        choices: [
          {
            index: 0,
            message: { role: 'assistant', content: 'Mock response: Hello from mock CLIProxyAPI gateway!' }
          }
        ]
      });
    }

    // 3. /v8/management/oauth/auth-url
    if (method === 'POST' && pathname === '/v8/management/oauth/auth-url') {
      const provider = parsedUrl.searchParams.get('provider');
      const state = `mock-state-${Date.now()}`;
      pendingOAuthSession = { state, provider, status: 'wait', ticks: 0 };

      if (provider === 'xai') {
        return sendJson(200, {
          status: 'ok',
          flow: 'device',
          state,
          url: 'https://auth.x.ai/activate',
          user_code: 'MCK-9999',
          expires_in: 1800
        });
      } else {
        return sendJson(200, {
          status: 'ok',
          state,
          url: `https://auth.openai.com/authorize?state=${state}`
        });
      }
    }

    // 4. /v8/management/oauth/status
    if (method === 'GET' && pathname === '/v8/management/oauth/status') {
      const state = parsedUrl.searchParams.get('state');
      if (!pendingOAuthSession || pendingOAuthSession.state !== state) {
        return sendJson(404, { error: 'session not found' });
      }

      // Simulate completion after 2 polls
      pendingOAuthSession.ticks++;
      if (pendingOAuthSession.ticks >= 2) {
        pendingOAuthSession.status = 'ok';
      }

      return sendJson(200, {
        status: pendingOAuthSession.status,
        saved: pendingOAuthSession.status === 'ok',
        adopted: pendingOAuthSession.status === 'ok'
      });
    }

    // 5. /v8/management/oauth/session
    if (method === 'DELETE' && pathname === '/v8/management/oauth/session') {
      pendingOAuthSession = null;
      return sendJson(200, { success: true });
    }

    // 404
    sendJson(404, { error: 'Not found on mock server' });
  });

  return {
    server,
    listen: () => new Promise(resolve => server.listen(port, resolve)),
    close: () => new Promise(resolve => server.close(resolve)),
    url: `http://127.0.0.1:${port}`
  };
}
