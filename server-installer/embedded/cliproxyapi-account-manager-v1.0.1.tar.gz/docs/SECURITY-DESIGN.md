# Security Design & Threat Mitigation

## 1. Security Architecture Principles

1. **Defense in Depth:** Even on a private LAN, all web interactions require strong authentication, anti-CSRF tokens, and strict input validation.
2. **Zero-Token Exposure:** The browser and client UI NEVER receive access tokens, refresh tokens, id tokens, or private secrets. Only sanitized identities (e.g. `coo***@gmail.com`) and expiry metadata are transmitted.
3. **Least Privilege & Service Identity Rationale:**
   - Account Manager runs under the unprivileged system user `cliproxyapi:cliproxyapi`.
   - **Service Identity Rationale:** The primary operational requirement is reading and writing credential JSON files in `/var/lib/cliproxyapi/auths`, which must remain strictly mode `0600` owned by `cliproxyapi:cliproxyapi`.
   - Introducing a separate distinct user (e.g. `am-service`) would require either:
     a) Relaxing credential file permissions to group-writable (`0660`), which violates CLIProxyAPI's strict `0600` security requirement; or
     b) Giving `sudo` / `setuid` privileges, which creates an unnecessary privilege escalation vector.
   - Therefore, running Account Manager under `User=cliproxyapi` and `Group=cliproxyapi` while locking down the application code with `ProtectSystem=full`, `ProtectHome=true`, `PrivateTmp=true`, and root-owned application files (`chmod 0755` dirs, `0644` files) enforces optimal least privilege without permission boundary dilution.
4. **Boundary Isolation:** CLIProxyAPI Management API does not need to be exposed over the LAN. If enabled, it only speaks locally via loopback (`127.0.0.1`).

## 2. Authentication & Session Protections

- **Password Hashing:** `crypto.scrypt` with random 16-byte salt, 64-byte key length.
- **Timing Attacks:** All password and CSRF comparisons utilize `crypto.timingSafeEqual` to avoid side-channel timing leaks.
- **Brute-Force Protection:** IP-based rate limiting restricts authentication attempts to 5 failed requests per 60-second window.
- **CSRF Protection:** State-changing requests (`POST`, `PUT`, `DELETE`) require a matching `x-csrf-token` header generated per session.
- **Session Expiration:** In-memory sessions expire automatically after 120 minutes of inactivity.

## 3. Filesystem & Path Traversal Prevention

- Credential operations strictly enforce `/^[a-zA-Z0-9_\-\.]+$/` and reject any path containing `..`, `/`, or `\\`.
- Files must end with `.json`.
- Targeted credential deletion is strictly limited to files prefixed with recognized AI providers (`codex-`, `xai-`, `antigravity-`, `claude-`). Deleting system configurations or arbitrary files is rejected.
- Automatic backup creation (`/var/lib/cliproxyapi/auths.bak.<timestamp>`) before any file deletion.
- Credential permissions maintained at `0600` (read/write by `cliproxyapi` owner only).

## 4. Audit Logging & Sanitization

All administrative actions (logins, logouts, OAuth initiations, deletions, and diagnostic tests) are recorded to `/var/log/cliproxyapi-account-manager/audit.log`. The `AuditLogger` sanitizes all data structures, replacing tokens and passwords with `[REDACTED]`.
