# Installation Guide (TX3 Debian 12 ARM64)

> **MANDATORY NOTICE:** This installation guide is prepared for future deployment. DO NOT execute these steps until final operator approval is granted.

## 1. Prerequisites
- Target Host: TX3 (`192.168.1.133`)
- OS: Debian 12 ARM64
- User Account: `root` (or `sudo`) for service installation
- Runtime: Node.js 18+ (`apt install -y nodejs`)
- CLIProxyAPI: v8.0.61 running under service `cliproxyapi`

## 2. Step-by-Step Installation

1. Copy the application package to TX3:
   ```bash
   scp -r D:/Workspace/CLI2API root@192.168.1.133:/opt/cliproxyapi-account-manager-src
   ```

2. Run dry-run validation:
   ```bash
   ssh root@192.168.1.133
   cd /opt/cliproxyapi-account-manager-src
   chmod +x deploy/deploy.sh deploy/rollback.sh
   ./deploy/deploy.sh --dry-run
   ```

3. Execute deployment:
   ```bash
   ./deploy/deploy.sh
   ```

4. Verify firewall:
   Ensure port 8320 is allowed across the trusted LAN:
   ```bash
   ufw allow from 192.168.1.0/24 to any port 8320 proto tcp comment "CLIProxyAPI Account Manager LAN"
   ```

5. Open your web browser:
   Navigate to `http://192.168.1.133:8320` and complete initial administrator setup.
