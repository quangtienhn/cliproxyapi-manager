# Architecture & System Design

## 1. System Context

CLIProxyAPI Account Manager is designed as an independent companion daemon running side-by-side with CLIProxyAPI v8.0.61 on the TX3 appliance (`192.168.1.133`).

```
+-------------------------------------------------------------------------+
|                                TX3 Appliance                            |
|                                                                         |
|  [Operator Browser] (LAN: 192.168.1.0/24)                              |
|           |                                                             |
|           | HTTP Port 8320 (Session Cookie + CSRF)                      |
|           v                                                             |
|  +-------------------------------------------------------------------+  |
|  |             CLIProxyAPI Account Manager (Node.js)                 |  |
|  |  - Auth & Session Manager (scrypt, CSRF token)                    |  |
|  |  - Web UI (Vanilla HTML/CSS/JS, zero client runtime deps)         |  |
|  |  - Provider Adapter Layer (Codex, xAI, Gemini-Deferred)           |  |
|  |  - Local Auth Store Engine (0600 file modes, atomic backups)      |  |
|  |  - Audit Logger (automatic token redaction)                       |  |
|  +---------------------------------+---------------------------------+  |
|                                    |                                    |
|              Direct Local Auth Store| Loopback HTTP (127.0.0.1:8317)     |
|              Read / Write (0600)   | Model discovery / Ping test        |
|                                    v                                    |
|              +-------------------------------------+                    |
|              |         CLIProxyAPI Gateway         |                    |
|              |               v8.0.61               |                    |
|              +-------------------------------------+                    |
|                                    |                                    |
|                                    v                                    |
|              +-------------------------------------+                    |
|              |     /var/lib/cliproxyapi/auths      |                    |
|              |   (codex-*.json, xai-*.json)        |                    |
|              +-------------------------------------+                    |
+-------------------------------------------------------------------------+
```

## 2. Technology Selection Rationale

1. **Runtime:** Native Node.js (Built-in HTTP, Crypto, File System, Test Runner).
   - *Why:* Debian 12 ARM64 ships with native Node.js. Zero external npm dependencies ensures immediate startup, minimal RAM footprint (<35MB), and no third-party supply-chain vulnerabilities.
2. **Frontend:** Pure semantic HTML5, CSS3, and modern Vanilla ES6+.
   - *Why:* Zero build step required (no Webpack, Vite, or Next.js overhead on ARM64). Fast, responsive rendering directly served from memory/disk.
3. **Storage:** Direct filesystem synchronization with `/var/lib/cliproxyapi/auths`.
   - *Why:* CLIProxyAPI v8.0.61 features a built-in file watcher. Writing or deleting credential files under `/var/lib/cliproxyapi/auths` triggers hot reload in CLIProxyAPI without needing to restart the daemon.

## 3. Provider Adapter Architecture

Each provider is implemented as an isolated class extending `BaseProviderAdapter`:
- `CodexAdapter`: Handles OpenAI browser authorization and inference tests.
- `XAIAdapter`: Handles xAI RFC 8628 Device Code polling flow.
- `GeminiDeferredAdapter`: Safely blocks Gemini requests with explicit explanatory errors.
