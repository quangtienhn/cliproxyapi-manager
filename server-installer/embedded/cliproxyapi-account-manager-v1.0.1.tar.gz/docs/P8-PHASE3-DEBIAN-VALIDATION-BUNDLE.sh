#!/usr/bin/env bash
# P8-PHASE3-DEBIAN-BUNDLE-FIX-008
# Run as root on Debian from an extracted release directory:
#   bash /path/to/this/bundle.sh /tmp/extracted-release
set -Eeuo pipefail
umask 077

RELEASE_ROOT="${1:?usage: $0 EXTRACTED_RELEASE_ROOT}"
if [[ "$(id -u)" -ne 0 ]]; then echo '[FAIL] root is required' >&2; exit 1; fi
if [[ ! -x "$RELEASE_ROOT/deploy/backup_phase3.sh" || ! -x "$RELEASE_ROOT/deploy/rollback_phase3.sh" ]]; then
  echo '[FAIL] extracted release root is invalid' >&2; exit 1
fi
if grep -nE '(^|[[:space:]])/(usr/)?sbin/systemctl([[:space:]]|$)' \
  "$RELEASE_ROOT/deploy/backup_phase3.sh" "$RELEASE_ROOT/deploy/rollback_phase3.sh" >/dev/null; then
  echo '[FAIL] release script contains an absolute systemctl invocation' >&2; exit 1
fi

WORK="$(mktemp -d /tmp/cliproxyapi-phase3-validation.XXXXXX)"
cleanup() {
  if [[ -n "${WORK:-}" && -d "$WORK" ]]; then rm -rf -- "$WORK"; fi
}
handle_signal() {
  trap - EXIT
  cleanup
  exit 1
}
trap cleanup EXIT
trap handle_signal INT TERM
BACKUPS="$WORK/backups"; SOURCE="$WORK/source"; TARGET="$WORK/target"; MOCKBIN="$WORK/bin"
mkdir -p "$BACKUPS" "$SOURCE" "$TARGET/config" "$TARGET/env" "$MOCKBIN"

pass() { echo "[PASS] $1"; }
fail() { echo "[FAIL] $1" >&2; exit 1; }
assert_path_inside_work() {
  local p="$1"; local r
  r="$(realpath -m -- "$p")"
  [[ "$r" == "$WORK"/* ]] || fail "path escaped test root: $p"
}
for p in "$BACKUPS" "$SOURCE" "$TARGET" "$MOCKBIN"; do assert_path_inside_work "$p"; done
assert_owner() { [[ "$(stat -c '%u:%g' "$1")" == "$2" ]] || fail "owner mismatch: $1"; }
assert_mode() { [[ "$(stat -c '%a' "$1")" == "$2" ]] || fail "mode mismatch: $1"; }
assert_same() { cmp -s "$1" "$2" || fail "content mismatch: $3"; }

ROOT_OWNER="$(id -u):$(id -g)"
SERVICE_ACCOUNT=''
for candidate in cliproxyapi cliproxyapi-account-manager; do
  if getent passwd "$candidate" >/dev/null 2>&1; then SERVICE_ACCOUNT="$candidate"; break; fi
done
if [[ -n "$SERVICE_ACCOUNT" ]]; then SERVICE_OWNER="$(id -u "$SERVICE_ACCOUNT"):$(id -g "$SERVICE_ACCOUNT")"; else SERVICE_OWNER="$ROOT_OWNER"; fi
echo "[INFO] isolated root: $WORK"
echo "[INFO] fixture owner: $SERVICE_OWNER"

printf 'port: 8317\nmanagement:\n  allow-remote: false\n' > "$SOURCE/config.yaml"
printf 'PORT=8320\nCLIPROXYAPI_URL=http://127.0.0.1:8317\n' > "$SOURCE/manager.env"
cp "$SOURCE/config.yaml" "$WORK/original.config.yaml"
cp "$SOURCE/manager.env" "$WORK/original.manager.env"
chown "$SERVICE_OWNER" "$SOURCE/config.yaml" "$SOURCE/manager.env"
chmod 0600 "$SOURCE/config.yaml" "$SOURCE/manager.env"
CFG_OWNER="$(stat -c '%u:%g' "$SOURCE/config.yaml")"; CFG_MODE="$(stat -c '%a' "$SOURCE/config.yaml")"
ENV_OWNER="$(stat -c '%u:%g' "$SOURCE/manager.env")"; ENV_MODE="$(stat -c '%a' "$SOURCE/manager.env")"
assert_owner "$SOURCE/config.yaml" "$SERVICE_OWNER"; assert_mode "$SOURCE/config.yaml" 600
assert_owner "$SOURCE/manager.env" "$SERVICE_OWNER"; assert_mode "$SOURCE/manager.env" 600
pass 'fixture ownership and permissions'

atomic="$WORK/atomic.txt"; printf 'old\n' > "$atomic"; chown "$SERVICE_OWNER" "$atomic"; chmod 0600 "$atomic"
tmp="$(mktemp "$WORK/.atomic.XXXXXX")"; printf 'new\n' > "$tmp"; chown "$SERVICE_OWNER" "$tmp"; chmod 0600 "$tmp"; mv -f -- "$tmp" "$atomic"
assert_same "$atomic" <(printf 'new\n') 'atomic replacement'; assert_owner "$atomic" "$SERVICE_OWNER"; assert_mode "$atomic" 600
pass 'atomic mktemp/mv replacement'

POINTER="$BACKUPS/latest_phase3_backup"
MOCK_LOG="$WORK/systemctl.log"
assert_path_inside_work "$POINTER"; assert_path_inside_work "$MOCK_LOG"
printf '#!/usr/bin/env bash\nset -Eeuo pipefail\n[[ "${PHASE3_MOCK_SYSTEMCTL:-}" == 1 ]] || { echo "systemctl isolation failure" >&2; exit 97; }\nprintf "%%s\\n" "$*" >> "%s"\ncase "${1:-} ${2:-}" in\n  "is-active cliproxyapi"|"is-active cliproxyapi-account-manager") echo active;;\n  "restart cliproxyapi"|"restart cliproxyapi-account-manager") :;;\n  *) echo "unexpected systemctl invocation" >&2; exit 98;;\nesac\n' "$MOCK_LOG" > "$MOCKBIN/systemctl"
chmod 0755 "$MOCKBIN/systemctl"
MOCK_PATH="$MOCKBIN:/usr/sbin:/usr/bin:/sbin:/bin"
[[ "$(PATH="$MOCK_PATH" command -v systemctl)" == "$MOCKBIN/systemctl" ]] || fail 'mock systemctl is not first in PATH'
pass 'systemctl command resolution is isolated to mock'

run_backup() {
  env PHASE3_SOURCE_CONFIG="$SOURCE/config.yaml" PHASE3_SOURCE_ENV="$SOURCE/manager.env" \
    PHASE3_BACKUP_PARENT="$BACKUPS" PHASE3_POINTER_FILE="$POINTER" \
    bash "$RELEASE_ROOT/deploy/backup_phase3.sh" >/dev/null
  assert_path_inside_work "$POINTER"
  [[ -f "$POINTER" && ! -L "$POINTER" ]] || fail 'backup did not publish a regular pointer'
  assert_mode "$POINTER" 600; assert_owner "$POINTER" "$ROOT_OWNER"
  BACKUP_DIR="$(cat "$POINTER")"; assert_path_inside_work "$BACKUP_DIR"
  [[ "$BACKUP_DIR" == "$BACKUPS"/cliproxyapi-phase3-* ]] || fail 'pointer target is not direct backup child'
  (cd "$BACKUP_DIR" && sha256sum -c SHA256SUMS >/dev/null) || fail 'published backup checksum'
  pass 'backup publishes verified pointer only after checksum validation'
}
run_rollback() {
  local rollback_parent="${ROLLBACK_PARENT:-$BACKUPS}"
  local rollback_pointer="${ROLLBACK_POINTER:-$POINTER}"
  assert_path_inside_work "$rollback_parent"
  assert_path_inside_work "$rollback_pointer"
  env PATH="$MOCK_PATH" PHASE3_MOCK_SYSTEMCTL=1 PHASE3_BACKUP_PARENT="$rollback_parent" PHASE3_POINTER_FILE="$rollback_pointer" \
    PHASE3_TARGET_CONFIG="$TARGET/config/config.yaml" PHASE3_TARGET_ENV="$TARGET/env/manager.env" \
    PHASE3_SYSTEMCTL_BIN="$MOCKBIN/systemctl" PHASE3_NODE_BIN=node \
    bash "$RELEASE_ROOT/deploy/rollback_phase3.sh" >/dev/null
}
ROLLBACK_LOG="$WORK/rollback-validation.log"
assert_path_inside_work "$ROLLBACK_LOG"
expect_negative() {
  local label="$1"
  local expected_error="$2"
  : > "$ROLLBACK_LOG"
  : > "$MOCK_LOG"
  if run_rollback >"$ROLLBACK_LOG" 2>&1; then
    fail "$label accepted"
  fi
  grep -Fq -- "$expected_error" "$ROLLBACK_LOG" || fail "$label returned an unexpected validation error"
  [[ ! -s "$MOCK_LOG" ]] || fail "$label invoked systemctl"
  assert_same "$TARGET/config/config.yaml" "$WORK/baseline.target.config.yaml" "$label changed config"
  assert_same "$TARGET/env/manager.env" "$WORK/baseline.target.manager.env" "$label changed manager.env"
  pass "$label rejected for expected reason without service action or target writes"
}

run_backup
: > "$MOCK_LOG"
run_rollback
assert_same "$TARGET/config/config.yaml" "$WORK/original.config.yaml" 'restored config byte-for-byte'
assert_same "$TARGET/env/manager.env" "$WORK/original.manager.env" 'restored manager.env byte-for-byte'
assert_owner "$TARGET/config/config.yaml" "$CFG_OWNER"; assert_mode "$TARGET/config/config.yaml" "$CFG_MODE"
assert_owner "$TARGET/env/manager.env" "$ENV_OWNER"; assert_mode "$TARGET/env/manager.env" "$ENV_MODE"
pass 'restored content and metadata match original fixture'
(cd "$BACKUP_DIR" && sha256sum -c SHA256SUMS >/dev/null) || fail 'backup changed after rollback'
pass 'backup checksum and metadata remain intact'
expected_log=$'restart cliproxyapi\nrestart cliproxyapi-account-manager\nis-active cliproxyapi\nis-active cliproxyapi-account-manager'
assert_same "$MOCK_LOG" <(printf '%s\n' "$expected_log") 'systemctl order'
pass 'mock systemctl recorded expected restart and health-check order'

cp "$TARGET/config/config.yaml" "$WORK/baseline.target.config.yaml"
cp "$TARGET/env/manager.env" "$WORK/baseline.target.manager.env"

chmod 0640 "$POINTER"; expect_negative 'incorrect pointer permissions' 'Pointer file mode is'; chmod 0600 "$POINTER"

mv "$POINTER" "$WORK/pointer.real"; ln -s "$WORK/pointer.real" "$POINTER"
expect_negative 'symlinked pointer' 'Pointer file is an unexpected symlink'
rm "$POINTER"; mv "$WORK/pointer.real" "$POINTER"
run_backup
BACKUP_DIR="$(cat "$POINTER")"; SYMLINK_BACKUP="$BACKUPS/cliproxyapi-phase3-20260101T000001"
ln -s "$BACKUP_DIR" "$SYMLINK_BACKUP"; printf '%s\n' "$SYMLINK_BACKUP" > "$POINTER"; chmod 0600 "$POINTER"
expect_negative 'direct-child symlinked backup path' 'backup directory path is a symlink'
rm "$SYMLINK_BACKUP"

run_backup
BACKUP_DIR="$(cat "$POINTER")"; OUTSIDE_BACKUP="$WORK/outside-backup"
mkdir -p "$OUTSIDE_BACKUP"; ln -s "$OUTSIDE_BACKUP" "$BACKUPS/cliproxyapi-phase3-20260101T000002"
printf '%s\n' "$BACKUPS/cliproxyapi-phase3-20260101T000002" > "$POINTER"; chmod 0600 "$POINTER"
expect_negative 'backup symlink pointing outside parent' 'backup directory path is a symlink'
rm "$BACKUPS/cliproxyapi-phase3-20260101T000002"

run_backup
ln -s "$BACKUPS" "$WORK/intermediate-link"
printf '%s\n' "$WORK/intermediate-link/cliproxyapi-phase3-20260101T000003" > "$POINTER"; chmod 0600 "$POINTER"
expect_negative 'symlinked intermediate path component' 'Pointer path is not an authorized direct child'
rm "$WORK/intermediate-link"

run_backup
ln -s "$WORK/missing-backup" "$BACKUPS/cliproxyapi-phase3-20260101T000004"
printf '%s\n' "$BACKUPS/cliproxyapi-phase3-20260101T000004" > "$POINTER"; chmod 0600 "$POINTER"
expect_negative 'dangling backup symlink' 'backup directory path is a symlink'
rm "$BACKUPS/cliproxyapi-phase3-20260101T000004"

run_backup
ln -s "$BACKUPS" "$WORK/backup-parent-link"
ROLLBACK_PARENT="$WORK/backup-parent-link" ROLLBACK_POINTER="$WORK/backup-parent-link/$(basename "$BACKUP_DIR")" expect_negative 'symlinked backup parent' 'symlinked path component'
rm "$WORK/backup-parent-link"

run_backup
BACKUP_DIR="$(cat "$POINTER")"; printf 'tamper\n' >> "$BACKUP_DIR/manager.env"
expect_negative 'checksum mismatch' 'Backup integrity failure: SHA256SUMS do not match'

run_backup
BACKUP_DIR="$(cat "$POINTER")"; sed -i 's/SIZE=[0-9]*/SIZE=999999/' "$BACKUP_DIR/config.yaml.meta"
(cd "$BACKUP_DIR" && sha256sum config.yaml manager.env config.yaml.meta manager.env.meta > SHA256SUMS)
expect_negative 'tampered metadata' 'File size mismatch for'

run_backup
BACKUP_DIR="$(cat "$POINTER")"; printf 'port: 8317\nmanagement: [broken\n' > "$BACKUP_DIR/config.yaml"
stat -c 'UID=%u GID=%g MODE=%a SIZE=%s' "$BACKUP_DIR/config.yaml" > "$BACKUP_DIR/config.yaml.meta"
(cd "$BACKUP_DIR" && sha256sum config.yaml manager.env config.yaml.meta manager.env.meta > SHA256SUMS)
expect_negative 'malformed YAML containing port' 'Restored config.yaml failed structural validation'

run_backup
BACKUP_DIR="$(cat "$POINTER")"; printf 'BROKEN ENV LINE\n' > "$BACKUP_DIR/manager.env"
stat -c 'UID=%u GID=%g MODE=%a SIZE=%s' "$BACKUP_DIR/manager.env" > "$BACKUP_DIR/manager.env.meta"
(cd "$BACKUP_DIR" && sha256sum config.yaml manager.env config.yaml.meta manager.env.meta > SHA256SUMS)
expect_negative 'invalid manager.env' 'Restored manager.env failed structural validation'

echo '[PASS] all Debian validation assertions completed'
echo "[INFO] cleanup owns only: $WORK"
