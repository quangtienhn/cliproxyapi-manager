# P8 OAUTH COMPATIBILITY ARCHITECTURAL DECISION

**Document ID:** P8-OAUTH-COMPATIBILITY-DECISION-001  
**Project:** CLIProxyAPI Account Manager  
**Application Target:** TX3 (`192.168.1.133`)  
**Gateway Software:** CLIProxyAPI v8.0.61 (Commit `681ce41b`)  
**Evaluation Date:** 2026-11-10  

---

## 1. Architectural Status Decision

### **DECISION: SUPPORTED — LOOPBACK-ONLY MANAGEMENT API**

---

## 2. Evidence from CLIProxyAPI v8.0.61 Source Code

Analysis of the matching upstream v8.0.61 source code (`internal/api/server.go`, `internal/api/handlers/management/handler.go`, and `config.example.yaml`) establishes the exact operational mechanism:

1. **Route Enablement via Secret (`server.go:253-260`):**
   ```go
   hasManagementSecret := cfg.RemoteManagement.SecretKey != "" || envManagementSecret || s.localPassword != ""
   s.managementRoutesEnabled.Store(hasManagementSecret)
   if hasManagementSecret {
       s.registerManagementRoutes()
   }
   ```
   - When `management.secret-key` (or legacy `remote-management.secret-key`) is empty or unset, all `/v0/management` and `/v8/management` routes immediately return `404 Not Found`.
   - Configuring a management secret key enables the management HTTP router.

2. **Loopback-Only Enforcement (`handler.go:331-333, 398-400`):**
   ```go
   clientIP := c.ClientIP()
   localClient := clientIP == "127.0.0.1" || clientIP == "::1"
   ...
   if !localClient && !allowRemote {
       return false, http.StatusForbidden, "remote management disabled"
   }
   ```
   - When `allow-remote` is set to `false` (the default in CLIProxyAPI v8), any request from an IP other than `127.0.0.1` or `::1` is aborted with **HTTP 403 Forbidden** (`remote management disabled`), even if a valid management key header is provided.
   - Remote access from LAN (`192.168.1.0/24`) or WAN is physically rejected at the gateway middleware layer.

3. **Authentication Mechanism (`handler.go:334-347`):**
   - The loopback client sends:
     `Authorization: Bearer <management-key>` or `X-Management-Key: <management-key>`.
   - All management operations (such as `/v8/management/oauth/auth-url`) require this key.
   - OAuth redirect callbacks validate pending login state without exposing the key.

4. **Invariance of `/v1` Inference & HAOS Integration:**
   - Enabling `management` on loopback does **not** alter the `/v1/chat/completions` or `/v1/models` pipelines.
   - The Home Assistant integration on HAOS (`192.168.1.105`) connects directly to `http://192.168.1.133:8317/v1` using its client API key (`Bearer <client-key>`), completely unaffected by management settings.

---

## 3. Alternative Native CLI Workflows Evaluation

CLIProxyAPI v8.0.61 includes interactive command flags:
- `-codex-device-login`: Prompts for user activation on terminal.
- `-xai-login`: Prompts for user code on terminal.

**Why Native CLI Spawning was Rejected in Favor of Loopback Management API:**
- Subprocess execution (`child_process.spawn('/usr/local/bin/cliproxyapi', ['-xai-login'])`) from a Node.js web server requires scraping unbuffered ANSI terminal streams, is susceptible to deadlocks on interactive prompts (e.g. Google PKCE fallback prompt), and cannot reliably provide structured JSON status polling across browser sessions.
- In contrast, CLIProxyAPI's built-in Management API (`/v8/management/oauth/auth-url` and `/v8/management/oauth/status`) was designed explicitly for companion web dashboards (like CPAMC and Router-For-Me) to perform clean asynchronous polling.

---

## 4. Required Configuration Plan for TX3 (To Be Authorized by Operator)

To operationalize OAuth on TX3 safely without exposing Management API:

1. **Configuration Patch for `/etc/cliproxyapi/config.yaml`:**
   ```yaml
   management:
     allow-remote: false              # Enforce loopback-only (127.0.0.1)
     secret-key: "<generate-random-secret>" # Enables management router
     disable-control-panel: true     # Prevents public web assets
   ```

2. **Account Manager Environment (`/etc/cliproxyapi-account-manager/manager.env`):**
   ```env
   CLIPROXYAPI_URL=http://127.0.0.1:8317
   CLIPROXYAPI_MANAGEMENT_KEY="<same-random-secret>"
   ```

3. **Security Boundaries Preserved:**
   - **LAN/WAN Exposure:** Zero. Any external LAN client attempting to query `http://192.168.1.133:8317/v8/management/` receives `HTTP 403 Forbidden`.
   - **Secret Protection:** The secret key is stored strictly on TX3 filesystem mode `0640`, passed only over Unix loopback (`127.0.0.1`), never logged in audit files, and never sent to browser clients.

---

## 5. Verification Gate Status

- **Architecture Feasibility:** **100% PROVEN BY SOURCE CODE EVIDENCE**.
- **Mock Implementation:** **100% VERIFIED BY INTEGRATION TESTS**.
- **TX3 Physical Execution:** **NOT EXECUTED — WAITING FOR OPERATOR ACTION**.
