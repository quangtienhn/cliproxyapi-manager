# Configuration Reference

The configuration file is located at `/etc/cliproxyapi-account-manager/manager.env`.

| Variable | Default | Description |
|---|---|---|
| `PORT` | `8320` | TCP port for the Account Manager web service. |
| `HOST` | `0.0.0.0` | Listening address (bind to LAN interface). |
| `NODE_ENV` | `production` | Node environment flag. |
| `ADMIN_USERNAME` | `admin` | Default admin username. |
| `ADMIN_PASSWORD_HASH` | *Empty* | Password hash (`scrypt:<salt>:<hash>`). If empty, triggers web setup on first visit. |
| `CLIPROXYAPI_URL` | `http://127.0.0.1:8317` | Local loopback URL to the CLIProxyAPI daemon. |
| `AUTH_DIR` | `/var/lib/cliproxyapi/auths` | Local path where JSON credential files are stored. |
| `AUDIT_LOG_PATH` | `/var/log/cliproxyapi-account-manager/audit.log` | Destination for sanitized JSON audit log. |
| `SESSION_TTL_MINUTES` | `120` | Session idle timeout in minutes. |
| `COOKIE_SECURE` | `false` | Set to `true` if accessing behind an HTTPS reverse proxy. |
| `RATE_LIMIT_LOGIN_MAX`| `5` | Maximum failed login attempts allowed per IP before rate limiting. |
| `RATE_LIMIT_LOGIN_WINDOW_SEC` | `60` | Window in seconds for login rate limiting. |
