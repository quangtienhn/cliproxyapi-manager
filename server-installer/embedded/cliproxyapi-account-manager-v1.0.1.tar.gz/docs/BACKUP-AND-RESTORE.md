# Backup & Restore Procedures

## 1. Automated Deletion Backups

Prior to unlinking any credential file, the application automatically invokes `LocalAuthStore.createBackup()`.
Backups are saved to:
```
/var/lib/cliproxyapi/auths.bak.<timestamp>/
```
Each backup directory preserves the exact files with their existing metadata and permissions (`0600`).

## 2. Manual Backup Command

To perform an instantaneous manual backup of all active credentials on TX3:
```bash
sudo -u cliproxyapi cp -r /var/lib/cliproxyapi/auths /var/lib/cliproxyapi/auths.manual.bak.$(date +%Y%m%dT%H%M%S)
```

## 3. Restoration Procedure

If a credential file is accidentally deleted or corrupted:
1. Locate the backup folder:
   ```bash
   ls -ld /var/lib/cliproxyapi/auths.bak.*
   ```
2. Copy the desired credential back to `/var/lib/cliproxyapi/auths/`:
   ```bash
   sudo -u cliproxyapi cp /var/lib/cliproxyapi/auths.bak.YYYYMMDD/codex-user.json /var/lib/cliproxyapi/auths/
   chmod 0600 /var/lib/cliproxyapi/auths/codex-user.json
   ```
3. CLIProxyAPI's file watcher will automatically discover and reload the credential within seconds.
