# Operations Runbook

## 1. Service Management

```bash
# Check service status
systemctl status cliproxyapi-account-manager

# Restart service
systemctl restart cliproxyapi-account-manager

# Stop service
systemctl stop cliproxyapi-account-manager

# Inspect live logs
journalctl -u cliproxyapi-account-manager -f

# Inspect audit logs
tail -n 100 /var/log/cliproxyapi-account-manager/audit.log
```

## 2. Health Monitoring

A lightweight endpoint is provided for automated LAN monitors:
```bash
curl -s http://192.168.1.133:8320/api/health
# Response: {"status":"healthy","service":"cliproxyapi-account-manager","timestamp":"..."}
```

## 3. Routine Account Operations

1. **Viewing Accounts:** Open `http://192.168.1.133:8320` and log in. The dashboard displays all accounts loaded into CLIProxyAPI.
2. **Adding an Account:** Click `+ Add Account`, pick the provider, complete the verification (Device Code or Browser), and observe instant hot-loading.
3. **Removing an Account:** Click `Delete` on the specific account row. Confirm the prompt. The file is backed up before being unlinked.
