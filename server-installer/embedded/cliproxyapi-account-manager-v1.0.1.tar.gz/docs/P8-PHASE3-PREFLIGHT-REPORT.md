# P8 PHASE 3 PREFLIGHT & READ-ONLY AUDIT REPORT
**Document ID:** P8-PHASE3-PREFLIGHT-REPORT-001  
**Target:** TX3 `192.168.1.133`  
**Application Target:** CLIProxyAPI v8.0.61 (Commit `681ce41b`) & Account Manager v1.0.0  
**Audit Status:** `READ-ONLY AUDIT COMPLETED — ZERO SYSTEM MODIFICATIONS MADE`

---

## 1. Executive Summary of Audit Findings

The live read-only audit of TX3 revealed key architectural discoveries:

1. **Exact Binary Version (VERIFIED FROM TX3):**
   - Binary: `/usr/local/bin/cliproxyapi`
   - Version: `8.0.61`, Git Commit: `681ce41b`, BuiltAt: `2026-11-08T14:32:20Z`.
   - Matching local source code tree in `CLI2API-Engineering/.tmp/src/CLIProxyAPI-8.0.61` is 100% identical.

2. **Management Section Already Present (VERIFIED FROM TX3):**
   - In `/etc/cliproxyapi/config.yaml`, lines 64-66:
     ```yaml
     64: management:
     65:   allow-remote: false
     66:   secret-key: ...
     ```
   - **`allow-remote: false` is ALREADY configured.**
   - A `secret-key` entry is already defined under `management`.

3. **Critical Discovery: Socket Binding and Loopback Reachability (VERIFIED FROM TX3):**
   - Line 42-43 of `/etc/cliproxyapi/config.yaml`:
     ```yaml
     host: "192.168.1.133"
     port: 8317
     ```
   - Socket listener (`ss -lntp`):
     ```text
     LISTEN 0 4096 192.168.1.133:8317 0.0.0.0:* users:(("cliproxyapi",pid=2493441,fd=4))
     ```
   - **Crucial Architectural Impact:** CLIProxyAPI is currently bound strictly to IP `192.168.1.133`, **NOT** loopback `127.0.0.1` and **NOT** wildcard `0.0.0.0`.
   - Because it is bound exclusively to `192.168.1.133:8317`, connecting to `http://127.0.0.1:8317` will fail at the TCP socket layer (Connection refused), while connecting to `http://192.168.1.133:8317` from TX3 local processes presents a `clientIP` of `192.168.1.133` (which is rejected by `allow-remote: false` as remote).
   - In CLIProxyAPI v8.0.61, binding `host: "0.0.0.0"` or configuring `allow-remote: false` with localhost socket support is the essential prerequisite for local Account Manager communication.

4. **Firewall Boundary Verification (VERIFIED FROM TX3):**
   - Port 8317 inbound rule: `ip saddr 192.168.1.105 tcp dport 8317 accept`. Only HAOS is permitted from outside TX3.
   - Port 8320: Completely absent from `/etc/tx3-firewall.nft` (closed to LAN/WAN).

---

## 2. Evidence-Based Analysis: Loopback & Management Security

### A. Loopback Enforcement (`internal/api/handlers/management/handler.go:331-400`)
```go
clientIP := c.ClientIP()
localClient := clientIP == "127.0.0.1" || clientIP == "::1"
...
if !localClient && !allowRemote {
    return false, http.StatusForbidden, "remote management disabled"
}
```
- When `allow-remote: false`, callers presenting any IP other than `127.0.0.1` or `::1` receive **HTTP 403 Forbidden** (`"remote management disabled"`).
- Rejection occurs before any sensitive credential processing.

### B. Binding Architecture Analysis
In order for Account Manager to communicate with CLIProxyAPI over `127.0.0.1:8317`:
- CLIProxyAPI must listen on `127.0.0.1` as well as `192.168.1.133`.
- In CLIProxyAPI `config.yaml`, the `host` setting binds the server socket (`server.go:270`):
  `Addr: fmt.Sprintf("%s:%d", cfg.Host, cfg.Port)`
- When `host: "0.0.0.0"`, the socket listens on all local interfaces (both `127.0.0.1` and `192.168.1.133`).
- **Is `0.0.0.0` safe?** YES, because:
  1. The TX3 `nftables` firewall explicitly blocks all incoming external traffic to port 8317 except from source IP `192.168.1.105` (HAOS).
  2. The CLIProxyAPI `allow-remote: false` middleware forbids any management requests originating from outside `127.0.0.1`.
  3. HAOS on `192.168.1.105` only accesses `/v1/models` and `/v1/chat/completions`, completely isolated from `/v8/management`.

---

## 3. Account Manager Configuration Requirements

In `/etc/cliproxyapi-account-manager/manager.env`:
- `CLIPROXYAPI_URL=http://127.0.0.1:8317`
- `CLIPROXYAPI_MANAGEMENT_KEY="<secret-key-matching-config.yaml>"`

When Account Manager calls `/v8/management/oauth/auth-url?provider=codex` or `provider=xai`:
- Connects to `127.0.0.1:8317` -> client IP is `127.0.0.1` (`localClient == true`).
- Sends `Authorization: Bearer <CLIPROXYAPI_MANAGEMENT_KEY>`.
- Passes middleware check (`handler.go:348-355`) and dispatches OAuth flows.

---

## 4. Proposed Configuration Changes (NOT EXECUTED)

### Change 1: `/etc/cliproxyapi/config.yaml`
```yaml
# Update host listener from fixed IP to wildcard so 127.0.0.1 is available locally
host: "0.0.0.0"
port: 8317

management:
  allow-remote: false             # Guarantees no remote LAN/WAN management access
  secret-key: "<REDACTED_SECRET>" # Existing or newly synchronized secret
```

### Change 2: `/etc/cliproxyapi-account-manager/manager.env`
```env
CLIPROXYAPI_URL=http://127.0.0.1:8317
CLIPROXYAPI_MANAGEMENT_KEY="<REDACTED_SECRET>"
```

---

## 5. Exact Future Backup & Rollback Runbook (Prepared, Not Executed)

### A. Pre-Modification Backup Command Bundle
```bash
BACKUP_DIR="/var/backups/cliproxyapi-phase3-$(date +%Y%m%dT%H%M%S)"
mkdir -p "$BACKUP_DIR"
chmod 0700 "$BACKUP_DIR"

# Backup config.yaml and manager.env
cp -a /etc/cliproxyapi/config.yaml "$BACKUP_DIR/config.yaml"
cp -a /etc/cliproxyapi-account-manager/manager.env "$BACKUP_DIR/manager.env"
chmod 0600 "$BACKUP_DIR/config.yaml" "$BACKUP_DIR/manager.env"

# Record snapshot pointer
echo "$BACKUP_DIR" > /var/backups/latest_phase3_backup
```

### B. Instantaneous Rollback Command Bundle
```bash
BACKUP_DIR=$(cat /var/backups/latest_phase3_backup)
cp -a "$BACKUP_DIR/config.yaml" /etc/cliproxyapi/config.yaml
cp -a "$BACKUP_DIR/manager.env" /etc/cliproxyapi-account-manager/manager.env
systemctl restart cliproxyapi
systemctl restart cliproxyapi-account-manager
```

---

## 6. Risk Assessment & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| **Port 8317 exposure when binding 0.0.0.0** | None | Low | TX3 `nftables` inbound table explicitly drops non-HAOS traffic (`ip saddr 192.168.1.105 tcp dport 8317 accept`). External network boundary is preserved. |
| **Management API exposure on LAN** | None | High | `allow-remote: false` returns HTTP 403 Forbidden for any IP other than `127.0.0.1` and `::1`. |
| **HAOS integration disruption** | None | High | Changing `host: "0.0.0.0"` continues listening on `192.168.1.133:8317` for HAOS. No route or token changes for `/v1`. |
| **Secret leakage** | Low | High | Management key stored only in root-protected files (`0640` / `0600`). Never passed to browser; sanitized in audit log. |

---

## MANDATORY STOP CONDITION MET

- All preflight inspections were strictly read-only.
- **NO configurations were modified.**
- **NO secrets were generated or installed.**
- **NO services were restarted.**
- **NO backups were created on TX3.**
- **NO firewall rules were changed.**
- Awaiting separate operator instructions and explicit authorization for Phase 3 implementation.
