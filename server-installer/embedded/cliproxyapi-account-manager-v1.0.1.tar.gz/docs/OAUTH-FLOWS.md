# OAuth Flows & Provider Implementation

## 1. xAI (Grok) Device Code Flow (RFC 8628)

xAI authentication uses the standard OAuth2 Device Authorization Grant:

1. **Initiation:** Account Manager calls `/v8/management/oauth/auth-url?provider=xai`.
2. **Device Registration:** Upstream returns `verification_uri` (`https://auth.x.ai/activate`), `user_code` (e.g. `MCK-9999`), and `state`.
3. **UI Display:** The web UI displays the User Code and activation URL.
4. **User Action:** The operator opens `https://auth.x.ai/activate` on any device (phone, laptop) and inputs the 8-character code.
5. **Polling:** Account Manager polls `/v8/management/oauth/status?state=<state>` every 3 seconds.
6. **Completion:** Upon user approval, CLIProxyAPI generates `xai-<identity>-<hash>.json` with mode `0600`, hot-loads the 18 Grok models, and signals success to the web UI.

---

## 2. OpenAI Codex Browser Flow

OpenAI Codex authentication utilizes PKCE browser redirect flow:

1. **Initiation:** Operator requests Codex authentication.
2. **URL Generation:** CLIProxyAPI computes authorization URL with PKCE challenge and state.
3. **User Action:** Operator opens the authorization URL in a browser tab.
4. **Callback Handling:** CLIProxyAPI intercepts the callback on localhost forwarder, exchanges code for tokens, and writes `codex-<account>-<hash>.json`.
5. **Completion:** Account Manager polls status and reflects the active session in the dashboard.

---

## 3. Gemini / Antigravity Flow (Deferred)

Per Master Task guidelines, Gemini OAuth is intentionally deferred and safely disabled in the UI and backend adapter.
