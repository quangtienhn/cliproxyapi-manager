# Phase 3 Symlinked Backup Path — Root Cause Investigation

**Task:** `INVESTIGATE-PHASE3-SYMLINK-BACKUP-001`  
**Scope:** Read-only local source investigation  
**Production access:** None  
**Code changes:** None  
**Status:** Confirmed defect; not fixed by this investigation

## 1. Failing test and exact condition

The validation bundle creates the failing case at:

- `docs/P8-PHASE3-DEBIAN-VALIDATION-BUNDLE.sh:118-121`

The sequence is:

```bash
run_backup
BACKUP_DIR="$(cat "$POINTER")"
SYMLINK_BACKUP="$BACKUPS/cliproxyapi-phase3-20260101T000001"
ln -s "$BACKUP_DIR" "$SYMLINK_BACKUP"
printf '%s\n' "$SYMLINK_BACKUP" > "$POINTER"
expect_rollback_failure 'symlinked backup path'
```

The symlink is a direct child of the temporary backup parent and points to another valid backup directory that is also a direct child of that parent. The pointer therefore contains a symlink path, not the canonical target path.

The observed result, `[FAIL] symlinked backup path accepted`, is consistent with the current rollback implementation.

## 2. Production code path

The relevant production file is `deploy/rollback_phase3.sh`:

1. Lines `60-64` read and minimally validate the pointer text.
2. Line `68` canonicalizes the configured backup parent with `realpath -m`.
3. **Line `69` canonicalizes the pointer target with `realpath -m`.** This resolves the symlink before the symlink check.
4. Lines `71-78` check the canonical result. At line `75`, `[[ -L "$REAL_BACKUP_DIR" ]]` tests the already-resolved path, so it is false for the original symlink.
5. Lines `81-87` validate the canonical directory's parent and basename. Because the symlink target is another authorized direct child, these checks pass.
6. Lines `90-93` scan the resolved directory for internal symlinks, but cannot detect the symlink used by the pointer path itself.
7. Lines `101-114` verify the resolved target's files and checksums.
8. Lines `149-200` read from that resolved target and atomically restore the configured target files.

The backup producer, `deploy/backup_phase3.sh`, uses:

- Lines `50-58` to construct a timestamped child and avoid an existing path.
- Line `60` to create it with `mkdir -p`.
- Lines `65-109` to write metadata, copies and checksums.
- Lines `112-119` to create and atomically rename the pointer.

That producer does not create the symlink used by the failing test. The failing path is introduced after backup creation by the validation fixture and is consumed by rollback.

## 3. Root cause

**Root cause:** rollback canonicalizes the pointer's backup path before checking whether the original path is a symlink. The security check is applied to `REAL_BACKUP_DIR`, not to `RAW_BACKUP_DIR` or each path component of the original path.

This is a rollback path-validation defect, not a fixture defect and not a systemd/mock or path-override defect. The fixture deliberately creates a symlink in the exact location that rollback is supposed to reject.

The direct-child check does not compensate for this ordering because the symlink target is itself a valid direct child. `realpath -m` changes the identity being checked from:

```text
/tmp/.../backups/cliproxyapi-phase3-...0001   (symlink)
```

to:

```text
/tmp/.../backups/cliproxyapi-phase3-...0000   (regular directory)
```

The latter satisfies the existing checks.

## 4. Backup destination and write-flow assessment

The failing case does **not** cause the backup script to write through the test symlink: the symlink is created after `run_backup` completes. The backup script writes files under the string it constructs and only publishes the pointer after checksum verification.

However, the producer has related hardening gaps that should be considered separately:

- `BACKUP_PARENT` is configurable and is not independently checked for being a non-symlink, canonical `/var/backups` directory.
- The timestamp existence loop and subsequent `mkdir` are separate operations, so a privileged concurrent actor could race the destination path.
- The pointer update is atomic as a rename, but the destination path's parent and pre-existing objects are not comprehensively validated by the producer.

For the observed test, the immediate issue is rollback accepting an alias to a valid backup directory. A symlink to a target outside the authorized parent would normally be rejected after canonicalization because the canonical parent would no longer equal `REAL_PARENT`. The tested same-parent alias bypasses that protection.

## 5. Risk and impact

Severity: **High security-hardening defect; currently bounded impact.**

Impact demonstrated by the test:

- A pointer can reference a symlink path instead of a regular backup directory.
- Rollback follows the symlink and restores from the resolved backup directory.
- A caller able to modify the root-owned pointer or backup tree can select another authorized backup through an alias.

The current checks and root ownership/mode requirements limit ordinary LAN/user exploitation. The issue does not, by itself, demonstrate an arbitrary write outside the intended live restore targets, because rollback reads backup files and writes only `TARGET_CONFIG` and `TARGET_ENV`. It does weaken path identity and leaves a symlink/TOCTOU boundary unprotected. The producer's unchecked parent override and non-atomic destination creation increase the importance of closing the gap before implementation.

## 6. Minimal safe fix proposal

Do not use `realpath -m` as a substitute for validating the original path. Before canonicalization:

1. Require the raw pointer path to be absolute and contain exactly one authorized direct-child basename.
2. Reject `-L "$RAW_BACKUP_DIR"` immediately.
3. Reject symlinks in every component between `BACKUP_PARENT` and the raw backup directory, using `lstat`/`find -L` or an equivalent component-by-component check.
4. Canonicalize only after these checks and repeat the direct-parent/basename checks on the canonical result.
5. Use descriptor-relative or no-follow file opens where practical to reduce check/use races.

For the backup producer, separately validate the canonical parent and reject a symlinked or unexpected pre-existing destination before `mkdir`; retain the existing checksum-before-pointer-update ordering.

## 7. Required regression tests

Add tests that invoke the actual rollback script and assert failure with zero service calls for:

1. Direct-child symlink pointing to another valid direct-child backup (the current failing case).
2. Symlink pointing outside the backup parent.
3. Symlink in an intermediate path component.
4. Dangling backup symlink.
5. Regular direct-child backup, which must continue to pass.
6. Pointer replacement/race fixture where the path changes after canonicalization, if the test platform can safely model it.
7. Backup parent itself being a symlink, for the producer and rollback paths.
8. Pre-existing timestamp destination symlink and dangling symlink.

Each negative case must confirm no `systemctl restart` or health check occurs and that no files outside the test root are created or modified.

## 8. Conclusion

The failure is reproducible by source inspection and is caused by production rollback path-validation logic. It is not a false positive from the validation fixture. A minimal ordering/path-component validation fix should be safe, but it must be followed by the regression matrix above and a new release artifact. No source fix, deployment, rollback, TX3 access, service action, or release rebuild was performed in this investigation.
