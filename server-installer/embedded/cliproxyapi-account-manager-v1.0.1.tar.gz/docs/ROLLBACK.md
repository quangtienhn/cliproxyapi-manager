# Rollback Procedure

In the event that the Account Manager must be uninstalled or rolled back to an earlier release on TX3:

## 1. Automated Rollback (Preserves Credentials & History)

Execute the hardened rollback script provided in the deployment package:
```bash
sudo ./deploy/rollback.sh
```

### Safety & Execution Lifecycle:
1. **Root Privilege Enforcement:** Verifies execution as `root`.
2. **Pre-Restoration Validation (Service Untouched):**
   - The active service continues running during validation.
   - Validates `/var/backups/cliproxyapi-account-manager/latest_snapshot_path`.
   - Confirms that the target directory strictly resides within `/var/backups/cliproxyapi-account-manager/snapshot_*` and is not a symbolic link.
   - Confirms that the snapshot directory contains valid `app/`, `service_unit.service`, and `service_state.env`.
   - **Strict Data Parsing (No Shell Sourcing):** Parses `service_state.env` strictly as `key=val` for `WAS_ENABLED=yes|no` and `WAS_ACTIVE=yes|no`. Any arbitrary key, duplicate key, or command injection aborts safely with the active service untouched.
3. **Restoration Execution:**
   - Only after all validations pass is the current service stopped.
   - Atomically restores previous application directory and file modes (`root:root`, `0755` dirs, `0644` files).
   - Restores previous systemd unit.
   - Restores previous enabled/disabled and active/inactive states.
   - Deletes the snapshot pointer.
4. **Preservation Guarantees:**
   - Environment configuration at `/etc/cliproxyapi-account-manager/manager.env` is preserved.
   - Audit logs at `/var/log/cliproxyapi-account-manager/` are preserved.
   - All CLIProxyAPI credentials in `/var/lib/cliproxyapi/auths` remain **100% untouched**.
   - CLIProxyAPI service (`cliproxyapi.service`) remains **100% untouched**.

## 2. Explicit Uninstallation Mode

If the operator intends to completely remove the application and service rather than rolling back to a previous snapshot:
```bash
sudo ./deploy/rollback.sh --uninstall
```
This cleanly stops the service, disables the unit, removes `/etc/systemd/system/cliproxyapi-account-manager.service`, and deletes `/opt/cliproxyapi-account-manager`, while strictly preserving credentials, logs, and configuration.

## 3. Firewall Rollback (Native nftables)

If the firewall was updated to permit port 8320, restore the **exact** designated backup file (avoiding ambiguous wildcards):
```bash
# Example restoring exact timestamped backup:
sudo cp /etc/tx3-firewall.nft.bak.20261110T123000 /etc/tx3-firewall.nft
sudo /usr/local/sbin/tx3-fw-apply.sh --enforce
```

## 4. Impact Assessment
- The main CLIProxyAPI gateway service (`cliproxyapi.service`) is untouched.
- All credential files in `/var/lib/cliproxyapi/auths` (Codex, xAI) remain active and unchanged.
- Home Assistant (`192.168.1.105`) connectivity to `http://192.168.1.133:8317/v1` continues without interruption.
