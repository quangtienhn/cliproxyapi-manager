# Provider Support Matrix

| Provider | Type | Flow Implemented | Status | Models Supported | Notes |
|---|---|---|---|---|---|
| **OpenAI Codex** | `codex` | Browser Redirect / PKCE | **Fully Supported** | `gpt-4o`, `gpt-4o-mini`, `o1`, etc. | Production verified on TX3 (P3) |
| **xAI (Grok)** | `xai` | Device Code Flow (RFC 8628) | **Fully Supported** | `grok-2`, `grok-2-mini`, `grok-4.7` | Production verified on TX3 (P7-B) |
| **Google Gemini** | `gemini` | Deferred | **Intentionally Deferred** | N/A | Safe stub adapter returns explicit notice |
| **Anthropic Claude** | `claude` | Adapter ready | **Planned / Extensible** | `claude-3-5-sonnet`, etc. | Can be attached via plugin interface |

All provider adapters inherit from `BaseProviderAdapter`, ensuring modularity and clean future extensibility.
