# Changelog

All notable changes to the CLIProxyAPI Account Manager project are documented in this file.

## [1.0.0] - 2026-11-10

### Added
- **Core Server & Routing:** Native Node.js HTTP server (`src/server.js`) with zero third-party npm dependencies.
- **Security Engine:**
  - Password hashing and timing-safe verification using `scrypt` (`src/auth.js`).
  - In-memory session tracking with cryptographic CSRF token generation.
  - IP-based rate limiting to thwart brute-force password attempts.
  - Sanitized audit logging with automatic credential redaction (`src/audit.js`).
- **Auth Storage Engine:** Direct filesystem synchronization with `/var/lib/cliproxyapi/auths` supporting strict path traversal validation, automated pre-deletion backups, and email masking (`src/auth_store.js`).
- **Provider Adapters:**
  - OpenAI Codex adapter supporting browser authorization and model discovery (`src/providers/codex.js`).
  - xAI (Grok) adapter supporting RFC 8628 OAuth2 Device Code flow (`src/providers/xai.js`).
  - Google Gemini deferred adapter to safely prevent unintended authentication (`src/providers/gemini_deferred.js`).
- **Responsive LAN Web Console:** Single-page dashboard built with modern HTML5/CSS3/Vanilla JS (`public/`).
- **Deployment Suite:** Systemd service definition, deployment automation script, and clean rollback script (`deploy/`).
- **Automated Verification:** Comprehensive unit and integration test suite (`tests/`).
- **Complete Engineering Documentation:** 12 full documentation runbooks in `docs/`.
